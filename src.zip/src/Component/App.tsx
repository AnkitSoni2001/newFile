import React from "react";
import SignUp from "./SignUp";
import SignIn from "./SignIn";
import Dashboard from "./Dashboard";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import ProfileDetail from "./ProfileDetail";
import Home from "./Home";

import MyProfile from './MyProfile'; // Import the MyProfile component
import employeeImage from './img.png'; // Import the employee image
const employeeData = {
  id: 1,
  name: 'Jane Smith',
  position: 'Software Engineer',
  department: 'Engineering',
  email: 'jane.smith@example.com',
  phone: '123-456-7890',
  image: employeeImage, // Use the imported image
  skills: ['JavaScript', 'React', 'Node.js', 'SQL', 'Git'],
  experience: '5+ years',
  bio: 'Passionate about creating efficient and user-friendly web applications...',

};

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/signin" element={<SignIn />} />
        <Route path="/signup" element={<SignUp />} />
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/profiledetail" element={<ProfileDetail />} />
        <Route path="/home" element={<Home />} />
        <Route path="/myprofile" element={<MyProfile employee={employeeData} />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
