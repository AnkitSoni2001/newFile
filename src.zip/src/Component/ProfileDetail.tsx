import Cookies from "js-cookie";
import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

const ProfileDetail: React.FC = () => {
  var Navigate = useNavigate();

  const [info, setInfo] = useState({
    name: "",
    email: "",
  });

  useEffect(() => {
    var userInfo: string | undefined = Cookies.get("userInfo");
    if (userInfo !== undefined) {
      var Info: string | null = localStorage.getItem(userInfo);
      if (Info !== null) {
        setInfo(JSON.parse(Info));
      }
    }
  }, []);

  const handleLogOut = () => {
    Navigate("/login");
  };

  return (
    <div>
      <div className="head">
                <h2>My App</h2>
                <a href="/signin">
                    <button className="btn">Log Out</button>
                </a>
            </div>
      <div>
        <h1>My Profile</h1>
        <h3>{info.name}</h3>
        <h3>{info.email}</h3>
      </div>
      <div>
        {/* <button type="button" onClick={handleLogOut}>
          Log Out
        </button> */}
      </div>
    </div>
  );
};

export default ProfileDetail;
