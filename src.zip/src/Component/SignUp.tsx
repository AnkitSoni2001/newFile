import React from "react";
import { useState } from "react";
import { useNavigate } from 'react-router-dom'
import './Style.css'


const SignUp: React.FC = () => {

    var Navigate = useNavigate();

    const [name, setName] = useState<string>("");
    const [email, setEmail] = useState<string>("");
    const [password, setPassword] = useState<string>("");
    const [confirmPassword, setConfirmPassword] = useState<string>("");

    const Info = {
        name: name,
        email: email,
        password: password,
    }

    const handleSignUp = () => {
        if (name && email && password && confirmPassword) {
            if (password === confirmPassword) {
                if (localStorage.getItem(email) != null) {
                    alert("User already exist");
                    Navigate('/login')
                } else {
                    localStorage.setItem(email, JSON.stringify(Info));
                    alert("You have successfully Signed Up!");
                    Navigate('/signin')
                }
            } else {
                alert("Password not match!")
            }
        } else {
            alert("All fields are required!")
        }
    }

    return (
        <>
            <div className="head">
                <h2>My App</h2>
                <a href="/signin">
                    <button className="btn">Sign In</button>
                </a>
            </div>
            <form className="signUpForm">
                <div className="name">
                    <label className="lable">Name:</label>
                    <input className="input" type="text" value={name} onChange={(e) => setName(e.target.value)} />
                </div>
                <div className="email">
                    <label className="lable">Email:</label>
                    <input className="input" type="email" value={email} onChange={(e) => setEmail(e.target.value)} />
                </div>
                <div className="password">
                    <label className="lable">Password:</label>
                    <input className="input" type="password" value={password} onChange={(e) => setPassword(e.target.value)} />
                </div>
                <div className="password">
                    <label className="lable">Confirm Password:</label>
                    <input className="input" type="password" value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} />
                </div>
                <div>
                    <button type="button" className="btn1" onClick={handleSignUp}>Sign Up</button>
                </div>
            </form>
        </>
    )
}

export default SignUp;