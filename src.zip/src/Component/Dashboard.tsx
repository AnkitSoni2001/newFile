import Cookies from "js-cookie";
import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import './Style.css'

const Dashboard: React.FC = (e) => {

    var Navigate = useNavigate();

    const [info, setInfo] = useState({
        name: '',
        email: ''
    });

    useEffect(() => {
        var userInfo: string | undefined = Cookies.get('userInfo')
        if (userInfo !== undefined) {
            var Info: string | null = localStorage.getItem(userInfo)
            if (Info !== null) {
                setInfo(JSON.parse(Info));
            }

        }
    }, [])
    return (
        <>
            <div className="head">
                <h2>My App</h2>
                <a href="/profiledetail"><button className="pro_btn" type="button">My Profile</button></a>
                <a href="/signin">
                    <button className="btn">Log Out</button>
                </a>
            </div>
            <div>
                <h1>Welcome {info.name}</h1>
                {/* <h2>localStorage.</h2> */}
                {/* <a href="/ProfileDetail"><button type="button">Profile Detail</button></a> */}
            </div>
        </>
    )
}

export default Dashboard;