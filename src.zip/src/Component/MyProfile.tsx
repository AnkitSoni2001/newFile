import React, { useEffect, useState } from "react";
import Home from "./Home";
import "./MyProfile.css"; // You can create a separate CSS file for styling
import Cookies from "js-cookie";

interface Employee {
  id: number;
  name: string;
  position: string;
  department: string;
  email: string;
  phone: string;
  image: string;
  skills: string[];
  experience: string;
  bio: string;
}

interface MyProfileProps {
  employee: Employee;
}

const MyProfile: React.FC<MyProfileProps> = ({ employee }) => {

  const [info, setInfo] = useState({
    name: '',
    email: ''
});

useEffect(() => {
    var userInfo: string | undefined = Cookies.get('userInfo')
    if (userInfo !== undefined) {
        var Info: string | null = localStorage.getItem(userInfo)
        if (Info !== null) {
            setInfo(JSON.parse(Info));
        }

    }
}, [])

  return (
    <>
      <Home />
      <span className="heading">
        <h3>My Profile</h3>
      </span>
      <div className="profile-details">
        <img
          className="profile-image"
          src={employee.image}
          alt={employee.name}
        />
        <h1>{info.name}</h1>
      </div>
      <div className="otherdetails">
        <p>Position: {employee.position}</p>
        <p>Department: {employee.department}</p>
        <p>Email: {info.email}</p>
        <p>Phone: {employee.phone}</p>
        <h3>Skills:</h3>
        <ul>
          {employee.skills.map(skill => (
            <li key={skill}>{skill}</li>
          ))}
        </ul>
        <h3>Experience:</h3>
        <p>{employee.experience}</p>
        <h3>Bio:</h3>
        <p>{employee.bio}</p>
      </div>
    </>
  );
};

export default MyProfile;
