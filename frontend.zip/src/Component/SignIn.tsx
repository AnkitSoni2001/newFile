import Cookies from "js-cookie";
import React from "react";
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import "./Style.css";

const SignIn: React.FC = () => {
    var Navigate = useNavigate();
    const [email, setEmail] = useState<string>("");
    const [password, setPassword] = useState<string>("");

    const handleSignIn = () => {
        if (email && password) {
            var storedInfo = localStorage.getItem(email);
            if (storedInfo) {
                var parsedInfo = JSON.parse(storedInfo);
                if (parsedInfo.password === password) {
                    alert("You have successfully logged in!");
                    Cookies.set("userInfo", email);
                    Navigate("/home");
                }
            } else {
                alert("User not exist!");
                Navigate("/signup");
            }
        } else {
            alert("All fields are required!");
        }
    };

    return (
        <>
            <div className="head">
                <h2>My App</h2>
                <a href="/signup">
                    <button className="btn">Sign Up</button>
                </a>
            </div>
            <form className="loginForm">
                <div className="email">
                    <label className="lable">Email:</label>
                    <input className="input"
                        type="email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                    />
                </div>
                <div className="password">
                    <label className="lable">Password:</label>
                    <input className="input"
                        type="password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                    />
                </div>
                <div>
                    <button type="button" className="btn1" onClick={handleSignIn}>
                        Sign In
                    </button>
                </div>
            </form>
        </>
    );
};

export default SignIn;
