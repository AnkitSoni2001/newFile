export{}
const express = require('express')
const cors = require('cors')
const mssql = require('mssql')


const app = express();
app.use(cors())
app.use(express.json())
const port = 8000;

const config = {
    user: 'jmanassessment', 
    password: 'JMD##230',
    server: 'jmanassessment.database.windows.net',
    database: 'jmanassessment',


}

const pool = new mssql.ConnectionPool(config)

interface Info {
    id : number,
    name : string ,
    email: String,
}

class userData{
    async createTable(tableName) {
        try {
            await pool.connect()
            const checkTable = await this.tableExist(tableName)
            if(checkTable === false){
                const query:string = `Create Table ${tableName} (Id int primary key IDENTITY(1,1), Name varchar(30), Email varchar(50))`
                pool.request().query(query);
                console.log("table created")
            }     
        } catch (err) {
            console.log(err)
        };
    
    }
    
    async tableExist(tableName: string): Promise<boolean>{
        try{
            await pool.connect()
            const result = await pool.request().query(`SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = '${tableName}'`);
            // console.log(result);
            
            
            return result.recordset.length > 0; // Error may occur here
        }catch(err){
            console.log(err);
            return false;
        }
    }
    
    async userInput(tableName, userInfo:Info){
        try{
            await pool.connect()
            if(await this.tableExist(tableName)){
                const query = `INSERT INTO ${tableName}(Name , Email ) VALUES ('${userInfo.name}', '${userInfo.email}')`
                await pool.request().query(query);
            }
    
        }catch(err){
            console.log(err);
        }
    } 
}

const obj = new userData()
app.get('/signin', async(req, res) => {
    await pool.connect()

    // if (pool.connected) {
    //     console.log('Connected to the database');
    // }
    await obj.createTable("Users")
    
    res.send("Hello World")
})
app.post('/signup', async(req, res) => {
    const data = req.body
    if (data.name && data.email && data.password) {
        await pool.connect()
        const existUserQuery = `SELECT * FROM Users WHERE Email = '${data.email}'`
        const userExistData = await pool.request().query(existUserQuery)
        console.log(userExistData.recordset);
        
            if (userExistData.recordset.length !== 0) {
                res.json({message:"User already exist"});
            } else {
                await obj.userInput("Users",data).then(()=>{
                    res.json({message:"userCreated"})
                })        
            }
    } else {
        res.json({message:"All fields are required!"});
    }
    
})


app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
})